//CTimer.cpp, the timer class

#ifndef _WINDOWS

// ---- header files -----
#include "CTimeriOS.h"
// -----------------------

//constructor
CTimer::CTimer() 
{
} 

// destructor
CTimer::~CTimer()
{
}

unsigned int CTimer::time()
{
	return 0;
}

#endif // #ifdef _WINDOWS