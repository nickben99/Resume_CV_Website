//CTimer.cpp, the timer class

// ---- header files -----
#include "CTimeriOS.h"
// -----------------------

//constructor
CTimer::CTimer() 
{
} 

// destructor
CTimer::~CTimer()
{
}

unsigned int CTimer::time()
{
	return 0;
}