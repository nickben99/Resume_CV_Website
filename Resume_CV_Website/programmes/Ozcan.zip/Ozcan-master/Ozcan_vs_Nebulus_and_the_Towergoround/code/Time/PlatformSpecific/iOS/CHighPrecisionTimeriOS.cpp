//CHighPrecisionTimeriOS.cpp, the timer class

// ---- header files -----
#include "CHighPrecisionTimeriOS.h"
// -----------------------

void CHighPrecisionTimer::Start()
{
}

void CHighPrecisionTimer::Stop()
{
}

float CHighPrecisionTimer::Elapsed()
{
	return 0.0f;
}

bool CHighPrecisionTimer::Init()
{
	return true;
}