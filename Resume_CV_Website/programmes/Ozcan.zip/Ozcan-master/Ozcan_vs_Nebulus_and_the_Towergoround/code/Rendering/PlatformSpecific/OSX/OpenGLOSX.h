// OpenGLOSX.h

#ifdef OSX

#ifndef _OpenGLOSX_H_
#define _OpenGLOSX_H_

//--- System Includes -----------
//-------------------------------

//--- Header files --------------
#include <Rendering/OpenGLImplementationBase.h>
//-------------------------------

//--- external variables --------
//-------------------------------

//--- forward declerations --------
//-------------------------------

class OpenGLImplementation : public OpenGLImplementationBase
{
};

#endif

#endif