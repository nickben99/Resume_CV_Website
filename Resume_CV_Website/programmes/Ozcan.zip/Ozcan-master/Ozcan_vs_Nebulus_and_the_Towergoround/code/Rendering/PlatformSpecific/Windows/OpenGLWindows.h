// OpenGLOSX.h

#ifdef _WINDOWS

#ifndef _OpenGLWindows_H_
#define _OpenGLWindows_H_

//--- System Includes -----------
//-------------------------------

//--- Header files --------------
#include <Rendering/OpenGLImplementationBase.h>
//-------------------------------

//--- external variables --------
//-------------------------------

//--- forward declerations --------
//-------------------------------

class OpenGLImplementation : public OpenGLImplementationBase
{
};

#endif

#endif