// OpenGLImplementation.h

#ifndef _OpenGLiOS_H_
#define _OpenGLiOS_H_

//--- System Includes -----------
//-------------------------------

//--- Header files --------------
//-------------------------------

//--- external variables --------
//-------------------------------

class OpenGLImplementation
{
	private:

	public:

//---------------------------------------------
};

#endif