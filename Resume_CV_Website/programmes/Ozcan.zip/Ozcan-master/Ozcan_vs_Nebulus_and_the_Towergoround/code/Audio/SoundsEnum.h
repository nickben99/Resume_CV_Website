// SoundsEnum.h

//system includes---
//------------------

#ifndef _SoundsEnum_h_
#define _SoundsEnum_h_

enum SOUNDS
{
	SOUNDS_MAINMUSIC = 0,
	SOUNDS_MENUCHANGE,
	SOUNDS_MENUSELECT,
	SOUNDS_ENEMYEXPLODE,
	SOUNDS_KNOCKEDOFFPLATFORM,
	SOUNDS_LOSELIFE,
	SOUNDS_THROWFIREBALL,
	SOUNDS_COLLECTPOWERUP,
	SOUNDS_COUNT
};

#endif // ifndef _SoundsEnum_h_