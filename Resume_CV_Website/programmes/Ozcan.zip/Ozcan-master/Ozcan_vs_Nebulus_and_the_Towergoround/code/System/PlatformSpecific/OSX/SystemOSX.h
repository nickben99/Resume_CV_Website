//SystemOSX.h - useful defines

#ifndef _SystemOSX_h_
#define _SystemOSX_h_

#define SPRINTF sprintf

#define VSPRINTF vsprintf

#define SSCANF sscanf

inline void ErrorOutput(const char*) {

}

#endif // ifndef _SystemOSX_