// DebugiOS.h

#ifndef _WINDOWS

#ifndef _DebugiOS_H_
#define _DebugiOS_H_

//--- System Includes -----------
//-------------------------------

//--- Header files --------------
//-------------------------------

//--- external variables --------
//-------------------------------

class DebugImplementation
{
	private:

	public:

//---------------------------------------------
};

#endif

#endif