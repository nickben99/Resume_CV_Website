Thank-you for reviewing 'Ozcan vs Nebulus and the Towergoround'.

Please ensure the executables 'PLAY on macOS Ozcan vs Nebulus and the Towergoround' and 'PLAY on Windows Ozcan vs Nebulus and the Towergoround.exe' remain in the same directory as the folder 'Ozcan_vs_Nebulus_and_the_Towergoround'.  The game will not be playable if the executable files are moved to another directory or any of the contents of the 'Ozcan_vs_Nebulus_and_the_Towergoround' folder are deleted.

NOTE FOR MACOS: Double clicking on the executable to run the game may result in a warning that the application is from an untrusted developer. To run the game anyway, right click on the executable while holding down the control key, then select open from the pop up menu.

Benjamin Nickson