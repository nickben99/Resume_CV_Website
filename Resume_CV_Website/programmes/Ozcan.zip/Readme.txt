Thank-you for reviewing 'Ozcan vs Nebulus and the Towergoround'.

Please ensure the executable 'PLAY Ozcan vs Nebulus and the Towergoround.exe' remains in the same directory as the folder 'Ozcan_vs_Nebulus_and_the_Towergoround'.  The game will not be playable if the executable file is moved to another directory or any of the contents of the 'Ozcan_vs_Nebulus_and_the_Towergoround' folder are deleted.

Ben Nickson (Last updated 2016)